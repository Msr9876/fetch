package com.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.demo.beans.HotelBookingPageFactory;
import com.demo.beans.HotelLoginPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition
{
	
	private WebDriver driver;
	private HotelLoginPageFactory loginPageFactory;
	private HotelBookingPageFactory hotelBookingPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\dbelamag\\Downloads\\SeleniumWebDriver\\libs\\chromedriver.exe");
		this.driver = new ChromeDriver();

	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		this.driver.close();
	}
	
	
	
	
	@Given("user is on {string} Page")
	public void user_is_on_Page(String page) {
		driver.get(
				"file:///C:/Users/dbelamag/Desktop/selenium/StarterDemo/src/test/java/com/demo/htmlpages/"+page+".html");
		loginPageFactory = new HotelLoginPageFactory(driver);
		
	}

	@When("user enters invalid UserName")
	public void user_enters_invalid_UserName() {
		loginPageFactory.setUserName("DEEPIKA");
	}
	
	@When("user enters invalid Password")
	public void user_enters_invalid_Password() {
		loginPageFactory.setPassword("deepika123");
	}
	@When("user enters invalid UserName and Password")
	public void user_enters_invalid_UserName_and_Password() {
		loginPageFactory.setUserName("DEEPIKA");
		loginPageFactory.setPassword("deepika123");
	}
	


	@When("user enters valid details")
	public void user_enters_valid_details() {
		loginPageFactory.setUserName("DEEPIKA");
		loginPageFactory.setPassword("deepika123");
	}

	@Then("display {string} Page")
	public void display_Page(String page) {
		driver.get(
				"file:///C:/Users/dbelamag/Desktop/selenium/StarterDemo/src/test/java/com/demo/htmlpages/"+page+".html");
//				hotelBookingPageFactory = new HotelBookingPageFactory(driver);
//				hotelBookingPageFactory.setName("DEEPIKA");
//				hotelBookingPageFactory.setEmail("dee@gmail.com");
//				hotelBookingPageFactory.setPhone("9876789876");
//				hotelBookingPageFactory.setCity("chennai");
//				hotelBookingPageFactory.setState("tamilnadu");
			    
	}

	@When("user enters invalid Name and Email and Phone and City and State")
	public void user_enters_invalid_Name_and_Email_and_Phone_and_City_and_State() {
		hotelBookingPageFactory.setName("DEEPIKA");
		hotelBookingPageFactory.setEmail("dee@gmail.com");
		hotelBookingPageFactory.setPhone("9876789876");
		hotelBookingPageFactory.setCity("chennai");
		hotelBookingPageFactory.setState("tamilnadu");
		
	}

	@Then("user click the submit button and print {string}")
	public void user_click_the_submit_button_and_print(String message) throws InterruptedException {
		if (hotelBookingPageFactory.getName().equals("") ||
				hotelBookingPageFactory.getEmail().equals("")||
				hotelBookingPageFactory.getPhone().equals("")||
				hotelBookingPageFactory.getCity().equals("")||
				hotelBookingPageFactory.getState().equals("")) 
		{
			hotelBookingPageFactory.setError(message);
		} else {
			Thread.sleep(3000);
			hotelBookingPageFactory.setSubmitButton();
		}
	}




	@Then("user click the login button and print {string}")
	public void user_click_the_login_button_and_print(String message) throws InterruptedException {
		if (loginPageFactory.getUserName().equals("") || loginPageFactory.getPassword().equals("")) {
			loginPageFactory.setError(message);
		} else {
			Thread.sleep(3000);
			loginPageFactory.setLoginbutton();
		}
	}

}
